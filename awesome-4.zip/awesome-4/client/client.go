package main

import (
	"context"
	"fmt"
	"google.golang.org/grpc"
	"log"

	pb "awesome-4"
)

func main() {
	conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client := pb.NewUserServiceClient(conn)

	var name string
	var email string

	fmt.Print("Enter your name: ")
	fmt.Scanln(&name)

	fmt.Print("Enter your email: ")
	fmt.Scanln(&email)

	user := &pb.User{
		Name:  name,
		Email: email,
	}

	newUser, err := client.AddUser(context.Background(), user)
	log.Printf("User added: Name: %s, Email: %s\n", newUser.Name, newUser.Email)

	userId := &pb.UserId{Id: newUser.Id}
	getUser, err := client.GetUser(context.Background(), userId)
	log.Printf("GetUser: %v", getUser)

	list, err := client.UsersList(context.Background(), &pb.EmptyMessage{})
	log.Printf("List of users:")
	for _, u := range list.Users {
		fmt.Println("Id:", u.Id, "Name:", u.Name, "Email:", u.Email)
	}
}
