package main

import (
	"context"
	"google.golang.org/grpc/codes"
	"testing"

	pb "awesome-4"
	"google.golang.org/grpc"
)

type MockUserServiceServer struct {
	pb.UnimplementedUserServiceServer
	Users map[int32]*pb.User
}

func (s *MockUserServiceServer) AddUser(ctx context.Context, user *pb.User) (*pb.User, error) {
	user.Id = int32(len(s.Users) + 1)
	s.Users[user.Id] = user
	return user, nil
}
func (s *MockUserServiceServer) GetUser(ctx context.Context, userID *pb.UserId) (*pb.User, error) {
	user, ok := s.Users[userID.Id]
	if !ok {
		return nil, grpc.Errorf(codes.NotFound, "User not found")
	}
	return user, nil
}

func (s *MockUserServiceServer) UsersList(ctx context.Context, empty *pb.EmptyMessage) (*pb.UserList, error) {
	var userList []*pb.User
	for _, user := range s.Users {
		userList = append(userList, user)
	}
	return &pb.UserList{Users: userList}, nil
}

func TestUserService(t *testing.T) {
	mockServer := &MockUserServiceServer{
		Users: make(map[int32]*pb.User),
	}
	newUser := &pb.User{
		Id:    1,
		Name:  "Alice",
		Email: "alice@gmail.com",
	}
	addedUser, err := mockServer.AddUser(context.Background(), newUser)
	if err != nil {
		t.Errorf("AddUser returned error: %v", err)
	}
	if addedUser.Id != 1 {
		t.Errorf("AddUser returned user with wrong ID. Expected %d, got %d", 1, addedUser.Id)
	}

	userID := &pb.UserId{Id: 1}
	retrievedUser, err := mockServer.GetUser(context.Background(), userID)
	if err != nil {
		t.Errorf("GetUser returned error: %v", err)
	}
	if retrievedUser == nil {
		t.Error("GetUser returned nil user")
	}
	if retrievedUser.Id != 1 {
		t.Errorf("GetUser returned user with wrong ID. Expected %d, got %d", 1, retrievedUser.Id)
	}

	notFoundUserID := &pb.UserId{Id: 2}
	_, err = mockServer.GetUser(context.Background(), notFoundUserID)
	if grpc.Code(err) != codes.NotFound {
		t.Errorf("GetUser did not return NotFound error for non-existent user. Got %v", err)
	}

	usersList, err := mockServer.UsersList(context.Background(), &pb.EmptyMessage{})
	if err != nil {
		t.Errorf("UsersList returned error: %v", err)
	}
	if len(usersList.Users) != 1 {
		t.Errorf("UsersList returned wrong number of users. Expected %d, got %d", 1, len(usersList.Users))
	}
}
