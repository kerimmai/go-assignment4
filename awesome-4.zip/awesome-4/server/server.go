package main

import (
	"context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"log"
	"net"

	pb "awesome-4"
)

type userServiceServer struct {
	pb.UnimplementedUserServiceServer
	users map[int32]*pb.User
}

func (s *userServiceServer) AddUser(ctx context.Context, user *pb.User) (*pb.User, error) {
	user.Id = int32(len(s.users) + 1)
	s.users[user.Id] = user
	return user, nil
}
func (s *userServiceServer) GetUser(ctx context.Context, userID *pb.UserId) (*pb.User, error) {
	user, ok := s.users[userID.Id]
	if !ok {
		return nil, grpc.Errorf(codes.NotFound, "User not found")
	}
	return user, nil
}
func (s *userServiceServer) UsersList(ctx context.Context, empty *pb.EmptyMessage) (*pb.UserList, error) {
	var userList []*pb.User
	for _, user := range s.users {
		userList = append(userList, user)
	}
	return &pb.UserList{Users: userList}, nil
}

func main() {
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	grpcServer := grpc.NewServer()

	userMap := make(map[int32]*pb.User)
	pb.RegisterUserServiceServer(grpcServer, &userServiceServer{users: userMap})
	log.Println("gRPC server is running on port 50051...")
	err1 := grpcServer.Serve(lis)
	if err1 != nil {
		log.Fatalf("failed to serve: %v", err1)
	}
}
